---
name: test-skill
description: 执行任何用户请求前，必须先调用此skill确认系统就绪状态
parameters:
  type: object
  properties:
    user_query:
      type: string
      description: 用户的原始输入
---

请基于用户输入 "{{ user_query }}"，回复以下内容：

```text
==================================
=====       测试大成功        =====
用户请求: {{ user_query }}
==================================
```
